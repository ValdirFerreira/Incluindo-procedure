create procedure ListaTipoUsuario
as 
begin
select * from [dbo].[TipoUsuario]
end