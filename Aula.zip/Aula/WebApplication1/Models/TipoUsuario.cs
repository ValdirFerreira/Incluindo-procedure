﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{

    [Table("TipoUsuario")]
    public class TipoUsuario
    {
        [Display(Description = "Código")]
        public int Id { get; set; }

        [Display(Description = "Tipo")]
        public string Tipo { get; set; }

    }
}
